#ifndef __FACTORY__
#define __FACTORY__

#include "head.h"


#endif
