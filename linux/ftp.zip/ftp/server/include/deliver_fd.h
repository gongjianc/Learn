#ifndef __DELIVER_FD__
#define __DELIVER_FD__

#include "head.h"

void send_fd(int,int);

void recv_fd(int,int*);

#endif
