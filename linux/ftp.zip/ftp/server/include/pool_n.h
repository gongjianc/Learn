#ifndef __POOL_N__
#define __POOL_N__

#include "head.h"

void send_n(int,char*,int);

void recv_n(int,char*,int);

#endif
