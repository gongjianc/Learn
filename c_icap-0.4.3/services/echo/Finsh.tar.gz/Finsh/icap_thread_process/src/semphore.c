/*
 * =====================================================================================
 *
 *       Filename:  semphore.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  08/29/2014 09:30:14 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  tangyushan (), etangyushan@126.com
 *   Organization:  
 *
 * =====================================================================================
 */


/**Putting data on ring buffer**/

#include "session_buf.h"
#include "plog.h"
int sbuff_putdata(const int iringbuffer_ID, SESSION_BUFFER_NODE ft)
{
	log_printf (ZLOG_LEVEL_INFO, "%s__%d, buff_putdata", __FILE__, __LINE__);
    return 1;
    
}
